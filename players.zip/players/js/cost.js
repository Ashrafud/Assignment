function getInnerText(idName){
	getIdp=document.getElementById(idName);
	text=getIdp.innerText;
	return text;
}
function getValue(idName){
	getvalue1=document.getElementById(idName);
	getvalue2=getvalue1.value;
	return getvalue2;
}
function innerTextToValue(idName){
	getIdp=document.getElementById(idName);
	text=getIdp.value;
	texToValue=parseFloat(text)
	return texToValue;
}
function setInnerText(idName,innerValue){
	getId=document.getElementById(idName);
	getId.innerText=innerValue;
}

document.getElementById('calculatePlayerAmount').addEventListener('click',function(){
	playerRate=getValue('perPlayerRate');
	totalPlayerCost=playerRate*5;
	console.log(totalPlayerCost);
	setInnerText('tatal-Player-expenses',totalPlayerCost);

})
document.getElementById('totalCost').addEventListener('click',function(){
	playerRate=getValue('perPlayerRate');
	totalPlayerCost=playerRate*5;
	managerAmount=innerTextToValue('managerRate');
	coachAmount=innerTextToValue('coachRate');
	totalTeamCost=totalPlayerCost+managerAmount+coachAmount;

setInnerText('total-amount',totalTeamCost);

})

