
function getInnerText(idName){
	getIdp=document.getElementById(idName);
	text=getIdp.innerText;
	return text;
}
function setInnerText(idName,value){
	getId=document.getElementById(idName);
	getId.innerText=value;
}
function getPlayerName(btnName,playerName){
	document.getElementById(btnName).addEventListener('click',function(){
	a=document.getElementById(playerName);
	b=a.innerText;
	selectedPlayer1=getInnerText('selectedPlayer1');
	selectedPlayer2=getInnerText('selectedPlayer2');
	selectedPlayer3=getInnerText('selectedPlayer3');
	selectedPlayer4=getInnerText('selectedPlayer4');
	selectedPlayer5=getInnerText('selectedPlayer5');
	if (selectedPlayer1==='') {
		setInnerText('selectedPlayer1',b);
	}
	else if (selectedPlayer2==='') {
		setInnerText('selectedPlayer2',b);
	}
	else if (selectedPlayer3==='') {
		setInnerText('selectedPlayer3',b);
	}
	else if  (selectedPlayer4==='') {
		setInnerText('selectedPlayer4',b);
	}
	else if  (selectedPlayer5==='') {
		setInnerText('selectedPlayer5',b);
	}
	
	
})
}


getPlayerName('player-select-button1','playerName1');
getPlayerName('player-select-button2','playerName2');
getPlayerName('player-select-button3','playerName3');
getPlayerName('player-select-button4','playerName4');
getPlayerName('player-select-button5','playerName5');
getPlayerName('player-select-button6','playerName6');
getPlayerName('player-select-button7','playerName7');
getPlayerName('player-select-button8','playerName8');


document.getElementById('dlt-btn').addEventListener('click',function(){
	if (selectedPlayer1 !='') {
		setInnerText('selectedPlayer1','');
	}
})



