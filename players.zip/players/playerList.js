document.getElementById('abc').addEventListener('click',function(event){

	a=event.target.innerText;
	console.log(a);
})